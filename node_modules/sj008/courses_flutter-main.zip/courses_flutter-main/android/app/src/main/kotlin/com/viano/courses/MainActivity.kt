package com.viano.courses

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
